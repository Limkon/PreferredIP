﻿<#
.SYNOPSIS
    【终极二合一版】中文(简体) + 唯一美式键盘，彻底清除托盘幽灵微软拼音
    适用环境：Win10 / Win11 全版本通用
    临时允许脚本执行（当前会话）：
Set-ExecutionPolicy Bypass -Scope Process
#>

# 1. 管理员权限检测
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "[-] 请右键选择【以管理员身份运行】PowerShell！" -ForegroundColor Red
    Pause
    Exit
}

Write-Host "1. 正在终止相关进程以解除占用..." -ForegroundColor Yellow
Stop-Process -Name "SystemSettings" -Force -ErrorAction SilentlyContinue
Stop-Process -Name "TextInputHost" -Force -ErrorAction SilentlyContinue
Stop-Process -Name "ctfmon" -Force -ErrorAction SilentlyContinue

Write-Host "2. 正在禁用微软拼音底层 TSF 组件（杜绝托盘幽灵复活）..." -ForegroundColor Yellow
$pinyinGuid = "{81D4E9C9-1D3B-41BC-9E6C-4B40BF79E35E}"
$tipPath = "HKLM:\SOFTWARE\Microsoft\CTF\TIP\$pinyinGuid"
if (Test-Path $tipPath) {
    Rename-Item -Path $tipPath -NewName "${pinyinGuid}_Disabled" -Force -ErrorAction SilentlyContinue
    Write-Host "   [+] 已拔除微软拼音底层 COM 组件！" -ForegroundColor Green
}

Write-Host "3. 正在底层注入【美式键盘 (0804:00000409)】并清理拼音键值..." -ForegroundColor Yellow
# A. 写入经典键盘映射
$preloadPath = "HKCU:\Keyboard Layout\Preload"
$subPath     = "HKCU:\Keyboard Layout\Substitutes"
if (Test-Path $preloadPath) { Remove-Item $preloadPath -Recurse -Force }
New-Item -Path $preloadPath -Force | Out-Null
Set-ItemProperty -Path $preloadPath -Name "1" -Value "d0000804" -Type String

if (-not (Test-Path $subPath)) { New-Item -Path $subPath -Force | Out-Null }
Set-ItemProperty -Path $subPath -Name "d0000804" -Value "00000409" -Type String

# B. 重构现代语言架构，清理设置中的拼音残留
$zhPath = "HKCU:\Control Panel\International\User Profile\zh-Hans-CN"
if (-not (Test-Path $zhPath)) { New-Item -Path $zhPath -Force | Out-Null }
Get-Item -Path $zhPath | Select-Object -ExpandProperty Property | ForEach-Object {
    if ($_ -ne '(default)') { Remove-ItemProperty -Path $zhPath -Name $_ -Force -ErrorAction SilentlyContinue }
}
Set-ItemProperty -Path $zhPath -Name "0804:00000409" -Value 1 -Type DWord
Set-ItemProperty -Path "HKCU:\Control Panel\International\User Profile" -Name "Languages" -Value @("zh-Hans-CN") -Type MultiString

Write-Host "4. 正在清除托盘图标运行时缓存..." -ForegroundColor Yellow
$assemblyPath = "HKCU:\Software\Microsoft\CTF\SortOrder\AssemblyItem"
if (Test-Path $assemblyPath) {
    Remove-Item $assemblyPath -Recurse -Force -ErrorAction SilentlyContinue
}

Write-Host "5. 正在阻断系统自动修复计划任务..." -ForegroundColor Yellow
$taskPath = "\Microsoft\Windows\LanguageComponentsInstaller\"
@("Installation", "Uninstallation") | ForEach-Object {
    Disable-ScheduledTask -TaskPath $taskPath -TaskName $_ -ErrorAction SilentlyContinue | Out-Null
}

Write-Host "6. 正在同步到锁屏界面并重启托盘..." -ForegroundColor Yellow
$sysPreload = "Registry::HKEY_USERS\.DEFAULT\Keyboard Layout\Preload"
$sysSub     = "Registry::HKEY_USERS\.DEFAULT\Keyboard Layout\Substitutes"
if (Test-Path $sysPreload) { Remove-Item $sysPreload -Recurse -Force }
New-Item -Path $sysPreload -Force | Out-Null
Set-ItemProperty -Path $sysPreload -Name "1" -Value "d0000804" -Type String
if (-not (Test-Path $sysSub)) { New-Item -Path $sysSub -Force | Out-Null }
Set-ItemProperty -Path $sysSub -Name "d0000804" -Value "00000409" -Type String

# 重启桌面
Stop-Process -Name "explorer" -Force -ErrorAction SilentlyContinue
Start-Process "ctfmon.exe"
Start-Process "explorer.exe"

Write-Host "`n========================================================" -ForegroundColor Green
Write-Host "   终极配置完成！托盘与设置中均已彻底除名微软拼音。" -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Green