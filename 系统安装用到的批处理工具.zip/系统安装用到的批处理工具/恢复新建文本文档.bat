
@echo off
chcp 65001 >nul
setlocal

net session >nul 2>&1
if errorlevel 1 (
    echo 请右键本文件，选择“以管理员身份运行”。
    pause
    exit /b 1
)

echo 正在恢复新建文本文档菜单...

:: 恢复 .txt 文件类型关联
reg add "HKCR\.txt" /ve /t REG_SZ /d "txtfile" /f
reg add "HKCR\.txt" /v "Content Type" /t REG_SZ /d "text/plain" /f
reg add "HKCR\.txt" /v "PerceivedType" /t REG_SZ /d "text" /f

:: 恢复空白文本文档创建方式
reg add "HKCR\.txt\ShellNew" /v "NullFile" /t REG_SZ /d "" /f
reg add "HKCR\.txt\ShellNew" /v "ItemName" /t REG_EXPAND_SZ /d "@%%SystemRoot%%\System32\notepad.exe,-470" /f

:: 恢复传统 txtfile 类型
reg add "HKCR\txtfile" /ve /t REG_SZ /d "文本文档" /f
reg add "HKCR\txtfile\ShellNew" /v "NullFile" /t REG_SZ /d "" /f

:: 恢复传统文本文档打开方式
reg add "HKCR\txtfilelegacy" /ve /t REG_SZ /d "文本文档" /f
reg add "HKCR\txtfilelegacy\ShellNew" /v "NullFile" /t REG_SZ /d "" /f
reg add "HKCR\txtfilelegacy\shell\open\command" /ve /t REG_EXPAND_SZ /d "%%SystemRoot%%\System32\notepad.exe %%1" /f

echo.
echo 正在刷新资源管理器...
taskkill /f /im explorer.exe >nul 2>&1
start explorer.exe

echo.
echo 执行完毕。请检查右键“新建”菜单。
pause
