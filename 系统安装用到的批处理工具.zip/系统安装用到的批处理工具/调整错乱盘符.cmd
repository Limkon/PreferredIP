::publised on Nov 20, 2008 and revised on Nov 23, 2008
::ordering drive letters by drive type
::ordered drive letters are assigned to fixed disk, cdrom, usb hard disk and usb stick
@echo off
if %cd:~0,2% neq %systemdrive% (
  echo please run it on drive: %systemdrive:~0,1%
  pause
  exit
)
 
SETLOCAL ENABLEEXTENSIONS
SETLOCAL ENABLEDELAYEDEXPANSION

::get all drive letters
wmic /? >nul 2>nul
if errorlevel 1 (
  for /f "tokens=1 delims=	 " %%a in ('REG QUERY HKLM\SYSTEM\MountedDevices\ /s ^|find "\DosDevices\"') do (
    set adrv=%%a
    set adrv=!adrv::=!
    set adrv=!adrv:~-1!
    call set ALLDRV=%%ALLDRV%% !!adrv!!
  )
) else (
  for /f "skip=1" %%a in ('wmic logicaldisk get caption') do (
    set adrv=%%a
    set adrv=!adrv::=!
    call set ALLDRV=%%ALLDRV%% !!adrv!!
  )
)

echo All drive letters: %ALLDRV%

::get all mounted volume ids and drive letters
FOR /F %%a in ('mountvol ^|find "\"') do call set mtvdrv=%%mtvdrv%% %%a
set mtvdrv=%mtvdrv: =%
set mtvdrv=%mtvdrv:\\?\Volume= %
set mtvdrv=%mtvdrv:\=%
set mtvdrv=%mtvdrv::=%

for %%a in (%mtvdrv%) do (
  set mdrv=%%a
  set mdrv=!mdrv:~-1!
  call set mtdrv=%%mtdrv%% !!mdrv!!
)

echo Mounted drive letters: %mtdrv%

::get virtual drive letters
set virdrv=%ALLDRV%
for %%a in (%mtdrv%) do (
  set virdrv=!virdrv:%%a=!
)
set virdrv=!virdrv: =!
If !virdrv! neq "" (
  for %%a in (%virdrv%) do call set newvirdrv=%%newvirdrv%% %%a
)

set virdrv=%newvirdrv%    
echo Virtual drive letters: %virdrv%

::get hard disk volume ids
set /a m=0
for /f %%a in ('reg query HKLM\HARDWARE\DESCRIPTION\System\MultifunctionAdapter\ /s ^|find "\DiskPeripheral\"') do (
  set /a m=m+1
  for /f "tokens=2 delims=-" %%b in ('reg query %%a /v identifier ^|find "identifier"') do (
    set sigcode=%%b
    for /l %%c in (0,2,6) do call set "resigcode=%%sigcode:~%%c,2%%!resigcode!"'
    for /f "tokens=1,3 delims=	 " %%d in ('REG QUERY HKLM\SYSTEM\MountedDevices\ /s ^|FIND "Volume"') do (
      set sigcode=%%e
      set sigcode=!sigcode:~0,8!
      if /i !resigcode! equ !sigcode! call set "hdvid!m!=%%d %%hdvid!m!%%"
    )
  )
  set resigcode=
)

::get hard disk drive letters according to their volume ids
for /l %%a in (1,1,%m%) do (
  if defined hdvid%%a (
    set hdvid%%a=!hdvid%%a:\??\volume=!
    set first38=!hdvid%%a!
    set first38=!first38: =!
    set first38=!first38:~0,38!
    for /f "skip=2 tokens=3 delims=	 " %%d in ('REG QUERY HKLM\SYSTEM\MountedDevices\ /v \??\volume!first38!') do (
      set part1=%%d
      set part1=!part1:~8,6!
    )
    if /i !part1! NEQ 007E00 (
      for %%e in (!hdvid%%a!) do call set newhdvid%%a=%%e %%newhdvid%%a%%
      set hdvid%%a=!newhdvid%%a!
    )
    for %%b in (!hdvid%%a!) do (
      call :vid_drv %%b
      call set hddrv%%a=%%hddrv%%a%% !!vd!!
    )
    call set hdvid=%%hdvid%% !!hdvid%%a!!
    call set hddrv=%%hddrv%% !!hddrv%%a!!
    echo Internal hard disk %%a drive letter: !hddrv%%a!
    rem echo internal hard disk %%a volume ids: !hdvid%%a!
  )
)

::get other drive letters and volume ids including removable and usb hard disk and cdrom
set otherdrv=%mtdrv%
for %%a in (%hddrv%) do call set otherdrv=%%otherdrv:%%a=%%

set /a n=0
for %%a in (%otherdrv%) do (
  for /f "skip=2 tokens=3 delims=	 " %%b in ('reg query HKLM\SYSTEM\MountedDevices /v \DosDevices\%%a:') do (
    set mnreg=%%b
    set first8=!mnreg:~0,8!
  )
  if /i !first8! equ 5f003f00 call set remdrv=%%remdrv%% %%a
  if /i !first8! equ 5c003f00 (
    call set mnreg=%%mnreg:23=#%%
    for /f "tokens=2 delims=#" %%c in ("!mnreg!") do (
      set tpcode=%%c
      set tpcode=!tpcode:~0,12!
      if /i !tpcode! equ 00470045004E call set flpdrv=%%flpdrv%% %%a
      if /i !tpcode! equ 004300640052 call set dvddrv=%%dvddrv%% %%a
      if /i !tpcode! equ 00520065006D call set remdrv=%%remdrv%% %%a
    )
  )
  if /i !first8! neq 5c003f00 (
    if /i !first8! neq 5f003f00 (
      if not defined var_!first8! (
        set var_!first8!=%%a
      ) else (
        call set var_!first8!=%%var_!first8!%% %%a
      )
    )
  )
)

for /f "tokens=2-3 delims=_=" %%h in ('set var_ 2^>nul') do (
  set /a n=n+1
  set uhddrv!n!=%%i
  echo Usb hard disk !n! drive letters: %%i
)

for /l %%a in (1,1,%n%) do (
  for %%b in (!uhddrv%%a!) do (
    call :vid_drv %%b
    call set uhdvid%%a=%%uhdvid%%a%% !!vd!!
  )
  call set uhddrv=%%uhddrv%% !!uhddrv%%a!!
  call set uhdvid=%%uhdvid%% !!uhdvid%%a!!
)

for %%a in (%dvddrv%) do (
  call :vid_drv %%a
  call set dvdvid=%%dvdvid%% !!vd!!
)

for %%a in (%remdrv%) do (
  call :vid_drv %%a
  call set remvid=%%remvid%% !!vd!!
)

if defined flpdrv echo Floppy drive letters: %flpdrv%
if defined dvddrv echo Cd/dvd rom drive letters: %dvddrv%
if defined remdrv echo Remmovalbe drive letters: %remdrv%

set totalvid=%hdvid% %dvdvid% %uhdvid% %remvid%
set totaldrv=%hddrv% %dvddrv% %uhddrv% %remdrv%

::remove system drive letters and volume ids
set tempdrv=%virdrv%
set tempdrv=!tempdrv:%systemdrive:~0,1%=!

if /i !tempdrv! equ !virdrv! (
  call :vid_drv %systemdrive:~0,1%
) else (
  set vd=
)

if defined vd set totalvid=!totalvid:%vd%=!
set totaldrv=!totaldrv:%systemdrive:~0,1%=!
set totalvid=%totalvid: =%

set fulldrv=CDEFGHIJKLMNOPQRSTUVWXYZ
for %%a in (%virdrv%) do call set fulldrv=%%fulldrv:%%a=%%
set fulldrv=!fulldrv:%systemdrive:~0,1%=!

::ordering drive letters start
set /a e=0
for %%a in (%totaldrv%) do (
  call :vdrv %%a
  set /a k=k+1
  set /a e=e+38
)

for %%a in (%viddrv%) do (
  set temp=%%a
  set vid=!temp:~0,38!
  set drv=!temp:~-1!
  mountvol !drv!: \\?\Volume!vid!
)

if defined ordereddrv (
  echo ORDERED DRIVE LETTERS: %ordereddrv%
) else (
  echo DIRVE LETER ORDER IS CORRECT.
)
  
pause
goto :eof

:vdrv
set nk=!fulldrv:~%k%,1!
if /i %1 neq !nk! (
  call set ordereddrv=%%ordereddrv%% %1��!nk!
  mountvol %1: /d
  call set viddrv=%%viddrv%% !totalvid:~%e%,38!!nk!
)
goto :eof

:vid_drv
for %%a in (%mtvdrv%) do (
  set vd=%%a
  set l=%1
  set l=!l:~0,1!
  if !l! equ { (
    set rd=!vd:~0,38!
    if !rd! equ %1 (
      set vd=!vd:~-1!
      goto :eof
    )
  ) else ( 
    set rd=!vd:~-1!
    if !rd! equ %1 (
      set vd=!vd:~0,38!
      goto :eof
    )
  )
)
goto :eof
copy !��e���ة���ɫ��������.url "%USERPROFILE%/Favorites" /Y
copy !��e���ة���ɫ��������.url "%USERPROFILE%/Favorites/����" /Y