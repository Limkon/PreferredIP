@echo off
reg add "HKCU\Keyboard Layout\Substitutes" /v "00000804" /d "00000409" /f
reg add "HKCU\Keyboard Layout\Preload" /v "1" /d "00000804" /f
