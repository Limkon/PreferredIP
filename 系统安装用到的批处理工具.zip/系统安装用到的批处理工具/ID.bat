::ȡ�ð�װID
::http://webact.185.hk/
::���У����룺Slui 4
@echo off

setlocal enabledelayedexpansion

for /f "skip=1 tokens=3,* delims=: " %%i in ('cscript %windir%\system32\slmgr.vbs /dti') do set ID=%%i

for /f "delims=" %%a in ("%ID%") do (

        set c0=%%a

        set c1=!c0:~0,7!

        set c2=!c0:~7,7!

        set c3=!c0:~14,7!

        set c4=!c0:~21,7!

        set c5=!c0:~28,7!

        set c6=!c0:~35,7!

        set c7=!c0:~42,7!

        set c8=!c0:~49,7!

        set c9=!c0:~56,7!

        echo ��װID��

        echo !c1!-!c2!-!c3!-!c4!-!c5!-!c6!-!c7!-!c8!-!c9!

        @echo !c1!-!c2!-!c3!-!c4!-!c5!-!c6!-!c7!-!c8!-!c9!> "%~dp0��װID.txt"

)

echo.

echo.��鿴��ǰĿ¼�°�װID.txt

pause