# ==============================================================================
#  nano10 Builder - Windows 10 ר�ü��¾����
#  (�� OneDrive + �� Cortana/������̨ + �� Defender + ����Ӧ�ü��� + ����������ʼ�˵�)
# ==============================================================================

# 1. ȷ����ȷ��ִ�в���
if ((Get-ExecutionPolicy) -eq 'Restricted') {
    Set-ExecutionPolicy RemoteSigned -Scope CurrentUser -Confirm:$false
}

# 2. ������ʵ�ű�Ŀ¼
if ($PSScriptRoot) {
    $scriptDir = $PSScriptRoot
} else {
    $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
}
Set-Location $scriptDir

# 3. ��鲢ǿ���Թ���Ա��������
$adminSID = New-Object System.Security.Principal.SecurityIdentifier("S-1-5-32-544")
$adminGroup = $adminSID.Translate([System.Security.Principal.NTAccount])
$myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$myWindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($myWindowsID)
$adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator

if (-not $myWindowsPrincipal.IsInRole($adminRole)) {
    Write-Host "������������ԱȨ��..." -ForegroundColor Yellow
    $newProcess = New-Object System.Diagnostics.ProcessStartInfo "PowerShell"
    $newProcess.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$($MyInvocation.MyCommand.Definition)`""
    $newProcess.Verb = "runas"
    $newProcess.WorkingDirectory = $scriptDir
    [System.Diagnostics.Process]::Start($newProcess)
    exit
}

# 4. ����ȫ��˫����־
$logFile = Join-Path -Path $scriptDir -ChildPath "nano10_build_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
try {
    Start-Transcript -Path $logFile -Append -Force
} catch {
    Write-Host "��־��ʼ��ʧ��: $_" -ForegroundColor Red
}

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "    nano10 Builder (Pure Lite + Win10 Classic Master)     " -ForegroundColor Cyan
Write-Host " ��־�ļ�: $logFile" -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan

$mainOSDrive = $env:SystemDrive
$scratchDir  = Join-Path $mainOSDrive "scratchdir"
$workDir     = Join-Path $mainOSDrive "nano10"
$sourcesDir  = Join-Path $workDir "sources"

Write-Host "�������ܲ����Ĺ��ص�..." -ForegroundColor DarkGray
& dism.exe /English /Cleanup-Wim | Out-Null

if (Test-Path $workDir) { Remove-Item -LiteralPath $workDir -Recurse -Force -ErrorAction SilentlyContinue }
New-Item -ItemType Directory -Force -Path $sourcesDir | Out-Null

$DriveLetter = Read-Host "������ Windows 10 ISO ��������̷� (���� E)"
$DriveLetter = ($DriveLetter.TrimEnd(':').Trim()) + ":"

if (-not (Test-Path "$DriveLetter\sources\boot.wim") -or (-not (Test-Path "$DriveLetter\sources\install.wim") -and -not (Test-Path "$DriveLetter\sources\install.esd"))) {
    Write-Host "[����] �� $DriveLetter ��δ�ҵ���Ч�� Windows 10 ��װԴ��" -ForegroundColor Red
    Stop-Transcript
    pause
    exit
}

Write-Host "���ڸ��� Windows 10 ISO ���Ľṹ��������..." -ForegroundColor Green
& robocopy.exe "$DriveLetter" "$workDir" /E /XF "install.wim" "install.esd" /NDL /NFL /NJH /NJS | Out-Null

$srcWim = "$DriveLetter\sources\install.wim"
$srcEsd = "$DriveLetter\sources\install.esd"
$destWim = "$sourcesDir\install.wim"

if (Test-Path $srcWim) {
    Write-Host "��⵽ install.wim����ȡӳ��汾�б�..." -ForegroundColor Green
    & dism.exe /English /Get-WimInfo "/WimFile:$srcWim"
    $index = Read-Host "������Ҫ�����Ŀ��汾 Index ��� (ͨ��רҵ��Ϊ 3 ����ҵ��)"
    Write-Host "���ڵ���Ŀ��־���������..." -ForegroundColor Green
    & dism.exe /English /Export-Image "/SourceImageFile:$srcWim" "/SourceIndex:$index" "/DestinationImageFile:$destWim" /Compress:max /CheckIntegrity
} else {
    Write-Host "��⵽ install.esd����ȡӳ��汾�б�..." -ForegroundColor Yellow
    & dism.exe /English /Get-WimInfo "/WimFile:$srcEsd"
    $index = Read-Host "������Ҫ�����Ŀ��汾 Index ���"
    Write-Host "���ڽ�Ŀ��־��� ESD ת������Ϊ install.wim..." -ForegroundColor Green
    & dism.exe /English /Export-Image "/SourceImageFile:$srcEsd" "/SourceIndex:$index" "/DestinationImageFile:$destWim" /Compress:max /CheckIntegrity
}

$index = "1"

Write-Host "���� install.wim Ȩ��..." -ForegroundColor Green
attrib.exe -R -S -H "$destWim"
Start-Process -FilePath "takeown.exe" -ArgumentList "/F `"$destWim`"" -NoNewWindow -Wait
Start-Process -FilePath "icacls.exe" -ArgumentList "`"$destWim`" /grant *S-1-5-32-544:F /C /Q" -NoNewWindow -Wait
(Get-Item $destWim).IsReadOnly = $false

Write-Host "���ڹ��� install.wim �� $scratchDir..." -ForegroundColor Green
if (Test-Path $scratchDir) {
    Remove-Item -LiteralPath $scratchDir -Recurse -Force -ErrorAction SilentlyContinue
}
New-Item -ItemType Directory -Force -Path $scratchDir | Out-Null

$mountResult = & dism.exe /English /Mount-Image "/ImageFile:$destWim" "/Index:$index" "/MountDir:$scratchDir"
$mountResult | Out-Host

if (-not (Test-Path "$scratchDir\Windows\System32")) {
    Write-Host "[���ش���] ӳ�����ʧ�ܣ���ֹ���С�" -ForegroundColor Red
    Stop-Transcript
    pause
    exit
}

function Force-NukeFolderOrFile {
    param ([string]$Target)
    if (Test-Path -LiteralPath $Target) {
        Write-Host "����ǿ���Ƴ�: $Target" -ForegroundColor DarkGray
        Start-Process -FilePath "takeown.exe" -ArgumentList "/F `"$Target`" /R /D Y" -NoNewWindow -Wait
        Start-Process -FilePath "icacls.exe" -ArgumentList "`"$Target`" /grant *S-1-5-32-544:F /T /C /Q" -NoNewWindow -Wait
        attrib.exe -R -S -H "$Target" /S /D 2>$null
        Remove-Item -LiteralPath $Target -Recurse -Force -ErrorAction SilentlyContinue
    }
}

# ----------------- 1. ɾ������ UWP���ϸ񱣻� Win10 ��ʼ�˵����ִ������� -----------------
Write-Host "������������ UWP ԤװӦ��..." -ForegroundColor Yellow

# Win10 ���ı����嵥�����������ʼ�˵���ǲ���������
$preservedPackages = @(
    "*VCLibs*",
    "*UI.Xaml*",
    "*NET.Native*",
    "*ShellExperience*",
    "*StartMenuExperience*"
)

$appxPackages = Get-AppxProvisionedPackage -Path $scratchDir

foreach ($app in $appxPackages) {
    $shouldKeep = $false
    foreach ($pattern in $preservedPackages) {
        if ($app.PackageName -like $pattern -or $app.DisplayName -like $pattern) {
            $shouldKeep = $true
            break
        }
    }

    if ($shouldKeep) {
        Write-Host "���� Win10 ����������: $($app.DisplayName)" -ForegroundColor DarkGray
        continue
    }

    Write-Host "ɾ������Ӧ��: $($app.PackageName)" -ForegroundColor Cyan
    & dism.exe /Image:$scratchDir /Remove-ProvisionedAppxPackage "/PackageName:$($app.PackageName)" | Out-Null
}

$winAppsDir = Join-Path $scratchDir "Program Files\WindowsApps"
if (Test-Path $winAppsDir) {
    Write-Host "�������� Program Files\WindowsApps Ŀ¼..." -ForegroundColor DarkGray
    Start-Process -FilePath "takeown.exe" -ArgumentList "/F `"$winAppsDir`" /R /D Y" -NoNewWindow -Wait
    Start-Process -FilePath "icacls.exe" -ArgumentList "`"$winAppsDir`" /grant *S-1-5-32-544:F /T /C /Q" -NoNewWindow -Wait
    
    Get-ChildItem -Path $winAppsDir | Where-Object { 
        $dirName = $_.Name
        $isPreserved = $false
        foreach ($pattern in $preservedPackages) {
            if ($dirName -like $pattern) {
                $isPreserved = $true
                break
            }
        }
        -not $isPreserved
    } | ForEach-Object {
        Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
    }
}

# ----------------- 2. �Ƴ�ϵͳ��ѡ���ܰ� -----------------
Write-Host "�����Ƴ� Windows 10 ��ѡ���ܰ�..." -ForegroundColor Yellow
$packagesToRemove = @(
    "Microsoft-Windows-InternetExplorer-Optional-Package~",
    "Microsoft-Windows-MediaPlayer-Package~",
    "Microsoft-Windows-WordPad-FoD-Package~",
    "Microsoft-Windows-StepsRecorder-Package~",
    "Microsoft-Windows-MSPaint-FoD-Package~",
    "Microsoft-Windows-SnippingTool-FoD-Package~",
    "Microsoft-Windows-TabletPCMath-Package~",
    "Microsoft-Windows-PowerShell-ISE-FOD-Package~",
    "OpenSSH-Client-Package~",
    "*IME-ja-jp*",
    "*IME-ko-kr*",
    "*IME-zh-tw*",
    "Microsoft-Windows-Hello-Face-Package~",
    "Microsoft-Windows-Hello-BioEnrollment-Package~",
    "Microsoft-Windows-BitLocker-DriveEncryption-FVE-Package~",
    "Microsoft-Windows-TPM-WMI-Provider-Package~"
)

$installedPackages = & dism.exe /English /Image:$scratchDir /Get-Packages /Format:Table
$installedPackages = $installedPackages -split "`n" | Select-Object -Skip 1

foreach ($pat in $packagesToRemove) {
    $matched = $installedPackages | Where-Object { $_ -like "$pat*" }
    foreach ($m in $matched) {
        $pkgId = ($m -split "\s+")[0]
        if ($pkgId) {
            Write-Host "�Ƴ�ϵͳ����: $pkgId" -ForegroundColor DarkYellow
            & dism.exe /English /Image:$scratchDir /Remove-Package "/PackageName:$pkgId" /NoRestart | Out-Null
        }
    }
}

# ----------------- 3. ���׷��� Edge��OneDrive��Defender��Cortana �� Search ʵ�� -----------------
Write-Host "����������� Edge��OneDrive��Defender ��С��/����ʵ��..." -ForegroundColor Yellow

# 3.1 ��� WinRE
$recoveryDir = Join-Path $scratchDir "Windows\System32\Recovery"
Force-NukeFolderOrFile (Join-Path $recoveryDir "winre.wim")
Force-NukeFolderOrFile (Join-Path $recoveryDir "ReAgent.xml")

# 3.2 ��� Edge ��������壨���� EdgeWebView ���ݲ㣩
Force-NukeFolderOrFile (Join-Path $scratchDir "Program Files (x86)\Microsoft\Edge")
Force-NukeFolderOrFile (Join-Path $scratchDir "Program Files (x86)\Microsoft\EdgeUpdate")

# 3.3 �������� OneDrive
Force-NukeFolderOrFile (Join-Path $scratchDir "Windows\System32\OneDriveSetup.exe")
Force-NukeFolderOrFile (Join-Path $scratchDir "Windows\SysWOW64\OneDriveSetup.exe")
Force-NukeFolderOrFile (Join-Path $scratchDir "Program Files\Microsoft OneDrive")
Force-NukeFolderOrFile (Join-Path $scratchDir "Program Files (x86)\Microsoft OneDrive")
Force-NukeFolderOrFile (Join-Path $scratchDir "ProgramData\Microsoft OneDrive")
Force-NukeFolderOrFile (Join-Path $scratchDir "Users\Default\AppData\Local\Microsoft\OneDrive")

# 3.4 �������� Defender ʵ��
Force-NukeFolderOrFile (Join-Path $scratchDir "ProgramData\Microsoft\Windows Defender")
Force-NukeFolderOrFile (Join-Path $scratchDir "ProgramData\Microsoft\Windows Defender Advanced Threat Protection")
Force-NukeFolderOrFile (Join-Path $scratchDir "Program Files\Windows Defender")
Force-NukeFolderOrFile (Join-Path $scratchDir "Program Files (x86)\Windows Defender")
Force-NukeFolderOrFile (Join-Path $scratchDir "Program Files\Windows Defender Advanced Threat Protection")
Force-NukeFolderOrFile (Join-Path $scratchDir "Windows\System32\SecurityHealthSystray.exe")
Force-NukeFolderOrFile (Join-Path $scratchDir "Windows\System32\SecurityHealthService.exe")
Force-NukeFolderOrFile (Join-Path $scratchDir "Windows\System32\smartscreen.exe")
Force-NukeFolderOrFile (Join-Path $scratchDir "Windows\System32\InputMethod\CHT")
Force-NukeFolderOrFile (Join-Path $scratchDir "Windows\System32\InputMethod\JPN")
Force-NukeFolderOrFile (Join-Path $scratchDir "Windows\System32\InputMethod\KOR")

# 3.5 �������� Win10 ������ Cortana��С�ȣ��������̣��������� StartMenu
Write-Host "���� Windows 10 �������� (SearchApp.exe) �� Cortana..." -ForegroundColor Yellow
Get-ChildItem -Path (Join-Path $scratchDir "Windows\SystemApps") -Filter "*Search*" -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    Force-NukeFolderOrFile $_.FullName
}
Get-ChildItem -Path (Join-Path $scratchDir "Windows\SystemApps") -Filter "*Cortana*" -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    Force-NukeFolderOrFile $_.FullName
}
Get-ChildItem -Path (Join-Path $scratchDir "Windows\SystemApps") -Filter "Search*.exe" -File -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
    Force-NukeFolderOrFile $_.FullName
}

# ��������
$fontsPath = Join-Path $scratchDir "Windows\Fonts"
if (Test-Path $fontsPath) {
    Get-ChildItem -Path $fontsPath -Exclude "segoe*.*", "tahoma*.*", "marlett.ttf", "8541oem.fon", "segui*.*", "consol*.*", "calibri*.*", "arial*.*", "times*.*", "msyh*.*", "simsun*.*", "simhei*.*", "kaiu*.*", "mingliu*.*" | ForEach-Object {
        Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue
    }
}

# ----------------- 4. ����ע����޲� -----------------
Write-Host "���ڼ�������ע�����ʵʩ���Է�ɱ..." -ForegroundColor Green
$softwarePath = Join-Path $scratchDir "Windows\System32\config\SOFTWARE"
$systemPath   = Join-Path $scratchDir "Windows\System32\config\SYSTEM"
$ntuserPath   = Join-Path $scratchDir "Users\Default\ntuser.dat"

attrib.exe -R -S -H "$softwarePath" 2>$null
attrib.exe -R -S -H "$systemPath" 2>$null
attrib.exe -R -S -H "$ntuserPath" 2>$null

& reg.exe load HKLM\zSOFTWARE "$softwarePath" | Out-Null
& reg.exe load HKLM\zSYSTEM "$systemPath" | Out-Null
& reg.exe load HKLM\zNTUSER "$ntuserPath" | Out-Null

# ������������ȫɾ�����ܲ����ڵļ�ֵ����ֹ��ɫ��
function Safe-RegDelete {
    param ([string]$Key, [string]$Value = "")
    if ($Value) {
        cmd.exe /c "reg.exe delete `"$Key`" /v `"$Value`" /f 2>nul" | Out-Null
    } else {
        cmd.exe /c "reg.exe delete `"$Key`" /f 2>nul" | Out-Null
    }
}

# 4.1 ���׾�ɱ OneDrive
Write-Host "ȫ���ɱ OneDrive �Զ���װ��������..." -ForegroundColor Cyan
& reg.exe add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\OneDrive" /v "DisableFileSyncNGSC" /t REG_DWORD /d 1 /f | Out-Null
& reg.exe add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\OneDrive" /v "DisableFileSync" /t REG_DWORD /d 1 /f | Out-Null
& reg.exe add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\OneDrive" /v "DisableMeteredNetworkFileSync" /t REG_DWORD /d 1 /f | Out-Null
& reg.exe add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\OneDrive" /v "DisableLibrariesStylePin" /t REG_DWORD /d 1 /f | Out-Null

Safe-RegDelete "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Run" "OneDrive"
Safe-RegDelete "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Run" "OneDriveSetup"
Safe-RegDelete "HKLM\zSOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run" "OneDrive"
Safe-RegDelete "HKLM\zSOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run" "OneDriveSetup"
Safe-RegDelete "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\Run" "OneDrive"
Safe-RegDelete "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\Run" "OneDriveSetup"
Safe-RegDelete "HKLM\zSOFTWARE\Microsoft\Active Setup\Installed Components\{89820200-ECBD-11cf-8B85-00AA005B4383}"
Safe-RegDelete "HKLM\zSOFTWARE\WOW6432Node\Microsoft\Active Setup\Installed Components\{89820200-ECBD-11cf-8B85-00AA005B4383}"

& reg.exe add "HKLM\zSOFTWARE\Classes\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f | Out-Null
& reg.exe add "HKLM\zSOFTWARE\Classes\WOW6432Node\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f | Out-Null

# 4.2 ���׾�ɱ Windows 10 ������ WSearch ��������
Write-Host "���� Windows Search �����볣פ����..." -ForegroundColor Cyan
& reg.exe add "HKLM\zSYSTEM\ControlSet001\Services\WSearch" /v "Start" /t REG_DWORD /d 4 /f | Out-Null

& reg.exe add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "AllowCortana" /t REG_DWORD /d 0 /f | Out-Null
& reg.exe add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "DisableWebSearch" /t REG_DWORD /d 1 /f | Out-Null
& reg.exe add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "ConnectedSearchUseWeb" /t REG_DWORD /d 0 /f | Out-Null
& reg.exe add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\Windows Search" /v "AllowSearchToUseLocation" /t REG_DWORD /d 0 /f | Out-Null

# Win10 ���������������� (0 = ����)
& reg.exe add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\Search" /v "SearchboxTaskbarMode" /t REG_DWORD /d 0 /f | Out-Null
& reg.exe add "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\Search" /v "SearchboxTaskbarMode" /t REG_DWORD /d 0 /f | Out-Null

# 4.3 ������±��뾭����Ƭ�鿴�����Win10 ԭ�� txtfile ������
Write-Host "���� Win10 ԭ�� txtfile ������±�����..." -ForegroundColor Cyan
& reg.exe add "HKLM\zSOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\notepad.exe" /v "UseFilter" /t REG_DWORD /d 0 /f | Out-Null
Safe-RegDelete "HKLM\zSOFTWARE\Classes\Applications\notepad.exe" "NoOpenWith"

$notepadCmd = "`"C:\Windows\System32\notepad.exe`" `"%1`""

# Win10 ��ԭ�� txtfile Ϊ���Ժ���
& reg.exe add "HKLM\zSOFTWARE\Classes\.txt" /ve /t REG_SZ /d "txtfile" /f | Out-Null
Safe-RegDelete "HKLM\zSOFTWARE\Classes\.txt\OpenWithProgids"
& reg.exe add "HKLM\zSOFTWARE\Classes\.txt\OpenWithProgids" /v "txtfile" /t REG_NONE /d "" /f | Out-Null

& reg.exe add "HKLM\zSOFTWARE\Classes\txtfile" /ve /t REG_SZ /d "�ı��ĵ�" /f | Out-Null
& reg.exe add "HKLM\zSOFTWARE\Classes\txtfile\DefaultIcon" /ve /t REG_SZ /d "imageres.dll,-102" /f | Out-Null
& reg.exe add "HKLM\zSOFTWARE\Classes\txtfile\shell" /ve /t REG_SZ /d "open" /f | Out-Null
& reg.exe add "HKLM\zSOFTWARE\Classes\txtfile\shell\open\command" /ve /t REG_SZ /d $notepadCmd /f | Out-Null
& reg.exe add "HKLM\zSOFTWARE\Classes\txtfile\shell\edit\command" /ve /t REG_SZ /d $notepadCmd /f | Out-Null

# ��˲��ֻ����µ� txtfilelegacy
& reg.exe add "HKLM\zSOFTWARE\Classes\txtfilelegacy\shell\open\command" /ve /t REG_SZ /d $notepadCmd /f | Out-Null

Safe-RegDelete "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\notepad.exe"
& reg.exe add "HKLM\zSOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\notepad.exe" /ve /t REG_SZ /d "C:\Windows\System32\notepad.exe" /f | Out-Null
Safe-RegDelete "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\App Paths\notepad.exe"
Safe-RegDelete "HKLM\zNTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.txt"

# ������Ƭ�鿴��
$photoExts = @(".jpg", ".jpeg", ".png", ".bmp", ".gif", ".ico", ".tiff", ".tif", ".jfif")
& reg.exe add "HKLM\zSOFTWARE\RegisteredApplications" /v "Windows Photo Viewer" /t REG_SZ /d "SOFTWARE\Microsoft\Windows Photo Viewer\Capabilities" /f | Out-Null
foreach ($ext in $photoExts) {
    & reg.exe add "HKLM\zSOFTWARE\Microsoft\Windows Photo Viewer\Capabilities\FileAssociations" /v "$ext" /t REG_SZ /d "PhotoViewer.FileAssoc.Tiff" /f | Out-Null
    & reg.exe add "HKLM\zSOFTWARE\Classes\$ext" /ve /t REG_SZ /d "PhotoViewer.FileAssoc.Tiff" /f | Out-Null
    Safe-RegDelete "HKLM\zSOFTWARE\Classes\$ext\OpenWithProgids"
}

# 4.4 �ս� Defender
Write-Host "�ս� Windows Defender ��������..." -ForegroundColor Cyan
& reg.exe add "HKLM\zSOFTWARE\Policies\Microsoft\Windows Defender" /v "DisableAntiSpyware" /t REG_DWORD /d 1 /f | Out-Null
& reg.exe add "HKLM\zSOFTWARE\Policies\Microsoft\Windows Defender" /v "DisableAntiVirus" /t REG_DWORD /d 1 /f | Out-Null
& reg.exe add "HKLM\zSOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection" /v "DisableRealtimeMonitoring" /t REG_DWORD /d 1 /f | Out-Null

$defSvcs = @("WinDefend", "WdNisSvc", "WdNisDrv", "WdFilter", "Sense", "SecurityHealthService", "wscsvc")
foreach ($s in $defSvcs) {
    & reg.exe add "HKLM\zSYSTEM\ControlSet001\Services\$s" /v "Start" /t REG_DWORD /d 4 /f | Out-Null
}

# 4.5 �����������ƹ����̨Ԥװ
& reg.exe add "HKLM\zSOFTWARE\Policies\Microsoft\Windows\CloudContent" /v "DisableWindowsConsumerFeatures" /t REG_DWORD /d 1 /f | Out-Null

# ж���������õ�Ԫ
[System.GC]::Collect()
[System.GC]::WaitForPendingFinalizers()
Start-Sleep -Seconds 2

& reg.exe unload HKLM\zSOFTWARE | Out-Null
& reg.exe unload HKLM\zSYSTEM | Out-Null
& reg.exe unload HKLM\zNTUSER | Out-Null

# ----------------- 5. ��������뵼�� ESD -----------------
Write-Host "ִ���������������ӳ��..." -ForegroundColor Green
$cleanResult = & dism.exe /English /Image:$scratchDir /Cleanup-Image /StartComponentCleanup /ResetBase
if ($LASTEXITCODE -ne 0) {
    Write-Host "ResetBase �����ã�ִ�л����������..." -ForegroundColor Yellow
    & dism.exe /English /Image:$scratchDir /Cleanup-Image /StartComponentCleanup | Out-Null
}

& dism.exe /English /Unmount-Image "/MountDir:$scratchDir" /Commit

Write-Host "���ڽ� install.wim ����Ϊ��ѹ�� install.esd..." -ForegroundColor Green
$esdFile = Join-Path $sourcesDir "install.esd"
& dism.exe /Export-Image "/SourceImageFile:$destWim" "/SourceIndex:1" "/DestinationImageFile:$esdFile" /Compress:recovery /CheckIntegrity

if (Test-Path -LiteralPath $esdFile) {
    Write-Host "[�ɹ�] install.esd �ɹ����ɣ�ɾ����ʱ install.wim��" -ForegroundColor Green
    Remove-Item -LiteralPath $destWim -Force -ErrorAction SilentlyContinue
} else {
    Write-Host "[����] ESD ѹ��ʧ�ܣ�����ԭ�� install.wim��" -ForegroundColor Red
}

# ----------------- 6. ԭ���޲� boot.wim -----------------
Write-Host "�����Ż� boot.wim (Index 2)..." -ForegroundColor Green
$bootWimPath = Join-Path $sourcesDir "boot.wim"
attrib.exe -R -S -H "$bootWimPath" 2>$null

& dism.exe /English /Mount-Image "/ImageFile:$bootWimPath" /Index:2 "/MountDir:$scratchDir"
& dism.exe /English /Unmount-Image "/MountDir:$scratchDir" /Commit

# ----------------- 7. ������� ISO ���� -----------------
Write-Host "�����������մ��� Windows 10 ISO ����..." -ForegroundColor Green
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13
$oscdimgExe = Join-Path $scriptDir "oscdimg.exe"

if (-not (Test-Path $oscdimgExe)) {
    Write-Host "���� oscdimg �ٷ��������..." -ForegroundColor Yellow
    Invoke-WebRequest -Uri "https://msdl.microsoft.com/download/symbols/oscdimg.exe/3D44737265000/oscdimg.exe" -OutFile $oscdimgExe
}

$outputISO = Join-Path $scriptDir "nano10_purged.iso"
$etfsboot = Join-Path $workDir "boot\etfsboot.com"
$efisys = Join-Path $workDir "efi\microsoft\boot\efisys.bin"
$bootData = "2#p0,e,b`"$etfsboot`"#pEF,e,b`"$efisys`""

$oscdimgArgs = @(
    "-m",
    "-o",
    "-u2",
    "-udfver102",
    "-bootdata:$bootData",
    "$workDir",
    "$outputISO"
)

Start-Process -FilePath $oscdimgExe -ArgumentList $oscdimgArgs -NoNewWindow -Wait

Write-Host "==========================================================" -ForegroundColor Green
Write-Host " ����ɹ���Windows 10 ���´��� ISO ������:" -ForegroundColor Green
Write-Host " $outputISO" -ForegroundColor Green
Write-Host "==========================================================" -ForegroundColor Green

Read-Host "���س��� [ENTER] ������ʱ����Ŀ¼����ȫ�˳�..."

& dism.exe /English /Unmount-Image "/MountDir:$scratchDir" /Discard -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $workDir -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -LiteralPath $scratchDir -Recurse -Force -ErrorAction SilentlyContinue
Stop-Transcript